package com.example.nomnom;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class HomeFragment extends Fragment {
    private TextView dateTextView, nameTextView;
    private RadioGroup weekRadio;
    private ListView breakfastList, lunchList, dinnerList;
    private DBHandler dbHandler;
    private DateInfo dateInfo;
    String day;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.home_fragment, container, false);

        initializeViews(view);

        dateInfo = new DateInfo();
        String currentDay = dateInfo.getDayOfWeek();
        int currentDayMonth = dateInfo.getDayOfMonth();

        dateTextView.setText(dateInfo.getSelectedDate(getCheckedRadioButtonId(currentDay)));

        weekRadio.setOnCheckedChangeListener((group, checkedId) -> {
            String selectedDate = dateInfo.getSelectedDate(checkedId);
            dateTextView.setText(selectedDate);
            day = getDayOfWeekFromCheckedId(checkedId);
            loadMeals(day);
        });

        setMealItemClickListener(breakfastList, DBHandler.TABLE_BREAKFAST);
        setMealItemClickListener(lunchList, DBHandler.TABLE_LUNCH);
        setMealItemClickListener(dinnerList, DBHandler.TABLE_DINNER);

        dateInfo.switchWeekRadio(currentDay);
        dateInfo.setRadioDays(currentDayMonth);

        setName();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        weekRadio.setOnCheckedChangeListener((group, checkedId) -> {
            String selectedDate = dateInfo.getSelectedDate(checkedId);
            dateTextView.setText(selectedDate);
            day = getDayOfWeekFromCheckedId(checkedId);
            loadMeals(day);
        });
    }

    //listview item click listener
    private void setMealItemClickListener(ListView listView, String tableName) {
        listView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedMeal = (String) parent.getItemAtPosition(position);
            if(selectedMeal.equals("No meals added yet.")) return;
            Intent intent = new Intent(getActivity(), MealDetails.class);
            intent.putExtra("tableName", tableName);
            intent.putExtra("mealPosition", position);
            intent.putExtra("dayOfWeek", day);
            startActivity(intent);
        });
    }
    private void initializeViews(View view) {
        weekRadio = view.findViewById(R.id.weekdays_radiogroup);
        breakfastList = view.findViewById(R.id.breakfast_list);
        lunchList = view.findViewById(R.id.lunch_list);
        dinnerList = view.findViewById(R.id.dinner_list);
        dateTextView = view.findViewById(R.id.date);
        nameTextView = view.findViewById(R.id.main_name);
        dbHandler = new DBHandler(getActivity());
    }

    private void loadMeals(String dayOfWeek) {
        loadMealList(dayOfWeek, DBHandler.TABLE_BREAKFAST, breakfastList);
        loadMealList(dayOfWeek, DBHandler.TABLE_LUNCH, lunchList);
        loadMealList(dayOfWeek, DBHandler.TABLE_DINNER, dinnerList);
    }

    private void loadMealList(String dayOfWeek, String tableName, ListView listView) {
        Cursor cursor = dbHandler.getMeals(tableName, dayOfWeek);
        ArrayList<String> meals = new ArrayList<>();

        if (cursor.moveToFirst()) {
            int mealIndex = cursor.getColumnIndex(DBHandler.COLUMN_MEAL);
            do {
                String meal = (mealIndex != -1) ? cursor.getString(mealIndex) : "Unknown meal";
                meals.add(meal);
            } while (cursor.moveToNext());
        }
        cursor.close();

        if (meals.isEmpty()) {
            meals.add("No meals added yet.");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, meals);
        listView.setAdapter(adapter);
    }

    // Set user name
    private void setName() {
        SQLiteDatabase db = dbHandler.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + DBHandler.COLUMN_NAME + " FROM " + DBHandler.TABLE_USER_PROFILE, null);

        if (cursor.moveToFirst()) {
            int nameIndex = cursor.getColumnIndex(DBHandler.COLUMN_NAME);
            if (nameIndex != -1) {
                String name = cursor.getString(nameIndex);
                nameTextView.setText("Welcome " + name + "!");
            }
        }
        cursor.close();
    }

    private int getCheckedRadioButtonId(String day) {
        switch (day) {
            case "Sunday":
                return R.id.sunday;
            case "Monday":
                return R.id.monday;
            case "Tuesday":
                return R.id.tuesday;
            case "Wednesday":
                return R.id.wednesday;
            case "Thursday":
                return R.id.thursday;
            case "Friday":
                return R.id.friday;
            case "Saturday":
                return R.id.saturday;
            default:
                return R.id.sunday;
        }
    }

    private String getDayOfWeekFromCheckedId(int checkedId) {
        if (checkedId == R.id.sunday) {
            return "Sunday";
        } else if (checkedId == R.id.monday) {
            return "Monday";
        } else if (checkedId == R.id.tuesday) {
            return "Tuesday";
        } else if (checkedId == R.id.wednesday) {
            return "Wednesday";
        } else if (checkedId == R.id.thursday) {
            return "Thursday";
        } else if (checkedId == R.id.friday) {
            return "Friday";
        } else if (checkedId == R.id.saturday) {
            return "Saturday";
        }
        return "Sunday";
    }

    private class DateInfo {
        private String getSelectedDate(int checkedId) {
            Calendar calendar = Calendar.getInstance();
            int currentDay = calendar.get(Calendar.DAY_OF_WEEK);

            int offset = getOffsetForCheckedId(checkedId, currentDay);
            calendar.add(Calendar.DAY_OF_YEAR, offset);

            SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM d, yyyy", Locale.getDefault());
            return dateFormat.format(calendar.getTime());
        }
        private int getOffsetForCheckedId(int checkedId, int currentDay) {
            if (checkedId == R.id.sunday) {
                return Calendar.SUNDAY - currentDay;
            } else if (checkedId == R.id.monday) {
                return Calendar.MONDAY - currentDay;
            } else if (checkedId == R.id.tuesday) {
                return Calendar.TUESDAY - currentDay;
            } else if (checkedId == R.id.wednesday) {
                return Calendar.WEDNESDAY - currentDay;
            } else if (checkedId == R.id.thursday) {
                return Calendar.THURSDAY - currentDay;
            } else if (checkedId == R.id.friday) {
                return Calendar.FRIDAY - currentDay;
            } else if (checkedId == R.id.saturday) {
                return Calendar.SATURDAY - currentDay;
            }
            return 0;
        }

        public void switchWeekRadio(String day) {
            int checkedId = getCheckedRadioButtonId(day);
            String infoPasser = "";
            if (checkedId == R.id.sunday) {
                infoPasser = "Sunday";
            } else if (checkedId == R.id.monday) {
                infoPasser = "Monday";
            } else if (checkedId == R.id.tuesday) {
                infoPasser = "Tuesday";
            } else if (checkedId == R.id.wednesday) {
                infoPasser = "Wednesday";
            } else if (checkedId == R.id.thursday) {
                infoPasser = "Thursday";
            } else if (checkedId == R.id.friday) {
                infoPasser = "Friday";
            } else if (checkedId == R.id.saturday) {
                infoPasser = "Saturday";
            }
            DashboardFragment.daySelected = infoPasser;
            weekRadio.check(checkedId);
        }

        public void setRadioDays(int baseDay) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.DAY_OF_MONTH, baseDay);

            for (int i = 0; i < weekRadio.getChildCount(); i++) {
                RadioButton radioButton = (RadioButton) weekRadio.getChildAt(i);
                int offset = i - calendar.get(Calendar.DAY_OF_WEEK) + 1;
                calendar.add(Calendar.DAY_OF_YEAR, offset);
                String dayText = new SimpleDateFormat("EEE\nd", Locale.getDefault()).format(calendar.getTime());
                radioButton.setText(dayText);
                calendar.add(Calendar.DAY_OF_YEAR, -offset);
            }
        }
        public int getDayOfMonth() {
            return Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
        }
        public String getDayOfWeek() {
            SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.getDefault());
            return dayFormat.format(Calendar.getInstance().getTime());
        }
    }
}
