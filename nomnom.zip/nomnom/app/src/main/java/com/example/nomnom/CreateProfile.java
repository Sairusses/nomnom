package com.example.nomnom;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CreateProfile extends AppCompatActivity {

    EditText name, age, height, weight;
    Spinner sex;
    ImageButton create_profile;
    private DBHandler dbHandler;
    String nameString, ageString, heightString, weightString, sexString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        create_profile = findViewById(R.id.create_profile_button);
        dbHandler = new DBHandler(CreateProfile.this);
    }

    public void createProfile(View view) {
        name = findViewById(R.id.intro_name);
        age = findViewById(R.id.intro_age);
        height = findViewById(R.id.intro_height);
        weight = findViewById(R.id.intro_weight);
        sex = findViewById(R.id.sex_spinner);

        nameString = name.getText().toString();
        ageString = age.getText().toString();
        heightString = height.getText().toString();
        weightString = weight.getText().toString();
        sexString = sex.getSelectedItem().toString();

        if(nameString.isEmpty() || ageString.isEmpty() || heightString.isEmpty() || weightString.isEmpty()){
            Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            dbHandler.addNewProfile(nameString, ageString, heightString, weightString, sexString);

            SharedPreferences prefs = getSharedPreferences("UserProfile", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("isProfileCreated", true);
            editor.apply();

            startActivity(new Intent(this, MainActivity.class));
        }catch (Exception e) {
            Toast.makeText(this, "An error occurred.", Toast.LENGTH_SHORT).show();
        }

    }

}