package com.example.nomnom;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHandler extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "userProfile.db";
    private static final int DATABASE_VERSION = 2;

    // user profile table
    public static final String TABLE_USER_PROFILE = "user_profile";
    public static final String COLUMN_ID = "profile_id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_AGE = "age";
    public static final String COLUMN_HEIGHT = "height";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_SEX = "sex";

    // meals tables
    public static final String TABLE_BREAKFAST = "breakfast";
    public static final String TABLE_LUNCH = "lunch";
    public static final String TABLE_DINNER = "dinner";

    public static final String COLUMN_MEAL_ID = "meal_id";
    public static final String COLUMN_DAY_OF_WEEK = "day_of_week";
    public static final String COLUMN_MEAL = "meal";
    public static final String COLUMN_PROTEIN = "protein";
    public static final String COLUMN_FAT = "fat";
    public static final String COLUMN_CARBOHYDRATE = "carbohydrate";
    public static final String COLUMN_DESCRIPTION = "description";

    // create table statements
    private static final String TABLE_CREATE_USER_PROFILE =
            "CREATE TABLE " + TABLE_USER_PROFILE + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_NAME + " TEXT, " +
                    COLUMN_AGE + " INTEGER, " +
                    COLUMN_HEIGHT + " REAL, " +
                    COLUMN_WEIGHT + " REAL, " +
                    COLUMN_SEX + " TEXT);";

    private static final String TABLE_CREATE_BREAKFAST =
            "CREATE TABLE " + TABLE_BREAKFAST + " (" +
                    COLUMN_MEAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_DAY_OF_WEEK + " TEXT, " +
                    COLUMN_MEAL + " TEXT, " +
                    COLUMN_PROTEIN + " REAL, " +
                    COLUMN_FAT + " REAL, " +
                    COLUMN_CARBOHYDRATE + " REAL, " +
                    COLUMN_DESCRIPTION + " TEXT);";

    private static final String TABLE_CREATE_LUNCH =
            "CREATE TABLE " + TABLE_LUNCH + " (" +
                    COLUMN_MEAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_DAY_OF_WEEK + " TEXT, " +
                    COLUMN_MEAL + " TEXT, " +
                    COLUMN_PROTEIN + " REAL, " +
                    COLUMN_FAT + " REAL, " +
                    COLUMN_CARBOHYDRATE + " REAL, " +
                    COLUMN_DESCRIPTION + " TEXT);";

    private static final String TABLE_CREATE_DINNER =
            "CREATE TABLE " + TABLE_DINNER + " (" +
                    COLUMN_MEAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_DAY_OF_WEEK + " TEXT, " +
                    COLUMN_MEAL + " TEXT, " +
                    COLUMN_PROTEIN + " REAL, " +
                    COLUMN_FAT + " REAL, " +
                    COLUMN_CARBOHYDRATE + " REAL, " +
                    COLUMN_DESCRIPTION + " TEXT);";

    public DBHandler(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE_USER_PROFILE);
        db.execSQL(TABLE_CREATE_BREAKFAST);
        db.execSQL(TABLE_CREATE_LUNCH);
        db.execSQL(TABLE_CREATE_DINNER);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER_PROFILE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BREAKFAST);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LUNCH);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DINNER);
        onCreate(db);
    }
    //insert from TABLE_USER_PROFILE
    public void addNewProfile(String name, String age, String height, String weight, String sex){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_AGE, age);
        values.put(COLUMN_HEIGHT, height);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_SEX, sex);
        db.insert(TABLE_USER_PROFILE, null, values);
        db.close();
    }
    //insert from breakfast lunch or dinner
    public void addMeal(String table, String dayOfWeek, String meal, double protein, double fat, double carbohydrate, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DAY_OF_WEEK, dayOfWeek);
        values.put(COLUMN_MEAL, meal);
        values.put(COLUMN_PROTEIN, protein);
        values.put(COLUMN_FAT, fat);
        values.put(COLUMN_CARBOHYDRATE, carbohydrate);
        values.put(COLUMN_DESCRIPTION, description);
        db.insert(table, null, values);
        db.close();
    }
    //read from breakfast lunch or dinner
    public Cursor getMeals(String table, String dayOfWeek) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(table,
                new String[]{COLUMN_MEAL_ID, COLUMN_MEAL, COLUMN_PROTEIN, COLUMN_FAT, COLUMN_CARBOHYDRATE, COLUMN_DESCRIPTION},
                COLUMN_DAY_OF_WEEK + "=?",
                new String[]{dayOfWeek},
                null,
                null,
                null);
    }
    //delete all from breakfast lunch or dinner
    public void deleteAllMeals() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_BREAKFAST);
        db.execSQL("DELETE FROM " + TABLE_LUNCH);
        db.execSQL("DELETE FROM " + TABLE_DINNER);
        db.close();
    }
    //update
    public void updateMeal(String table, int mealId, String dayOfWeek, String meal, double protein, double fat, double carbohydrate, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DAY_OF_WEEK, dayOfWeek);
        values.put(COLUMN_MEAL, meal);
        values.put(COLUMN_PROTEIN, protein);
        values.put(COLUMN_FAT, fat);
        values.put(COLUMN_CARBOHYDRATE, carbohydrate);
        values.put(COLUMN_DESCRIPTION, description);
        db.update(table, values, COLUMN_MEAL_ID + "=?", new String[]{String.valueOf(mealId)});
        db.close();
    }
    public void deleteMeal(String table, int mealId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(table, COLUMN_MEAL_ID + "=?", new String[]{String.valueOf(mealId)});
        db.close();
    }

}