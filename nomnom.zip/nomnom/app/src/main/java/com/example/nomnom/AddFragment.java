package com.example.nomnom;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class AddFragment extends Fragment {
    private DBHandler dbHandler;
    private Context context;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.add_fragment, container, false);

        Button confirmButton = view.findViewById(R.id.confirm_meal);
        EditText mealText = view.findViewById(R.id.meal_name);
        EditText proteinText = view.findViewById(R.id.protein);
        EditText carbohydratesText = view.findViewById(R.id.carbohydrates);
        EditText fatsText = view.findViewById(R.id.fats);
        EditText descriptionText = view.findViewById(R.id.meal_description);
        Spinner mealForSpinner = view.findViewById(R.id.meals_spinner);

        CheckBox sunCheck = view.findViewById(R.id.sun_check);
        CheckBox monCheck = view.findViewById(R.id.mon_check);
        CheckBox tueCheck = view.findViewById(R.id.tue_check);
        CheckBox wedCheck = view.findViewById(R.id.wed_check);
        CheckBox thuCheck = view.findViewById(R.id.thu_check);
        CheckBox friCheck = view.findViewById(R.id.fri_check);
        CheckBox satCheck = view.findViewById(R.id.sat_check);

        dbHandler = new DBHandler(context);

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String meal = mealText.getText().toString();
                String proteinStr = proteinText.getText().toString();
                String carbohydratesStr = carbohydratesText.getText().toString();
                String fatsStr = fatsText.getText().toString();
                String description = descriptionText.getText().toString();
                String mealFor = mealForSpinner.getSelectedItem().toString();
                String table = "";
                if (meal.isEmpty() || proteinStr.isEmpty() || carbohydratesStr.isEmpty() || fatsStr.isEmpty() || description.isEmpty()) {
                    Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!sunCheck.isChecked() && !monCheck.isChecked() && !tueCheck.isChecked() && !wedCheck.isChecked() &&
                        !thuCheck.isChecked() && !friCheck.isChecked() && !satCheck.isChecked()) {
                    Toast.makeText(context, "Please select at least one day", Toast.LENGTH_SHORT).show();
                    return;
                }
                switch (mealFor){
                    case "Breakfast":
                        table = DBHandler.TABLE_BREAKFAST;
                        break;
                    case "Lunch":
                        table = DBHandler.TABLE_LUNCH;
                        break;
                    case "Dinner":
                        table = DBHandler.TABLE_DINNER;
                        break;
                }
                double protein = Double.parseDouble(proteinStr);
                double carbohydrates = Double.parseDouble(carbohydratesStr);
                double fats = Double.parseDouble(fatsStr);
                StringBuilder addedDays = new StringBuilder("Added to: ");
                if (sunCheck.isChecked()) {
                    dbHandler.addMeal(table, "Sunday", meal, protein, fats, carbohydrates, description);
                    addedDays.append("Sunday, ");
                }
                if (monCheck.isChecked()) {
                    dbHandler.addMeal(table, "Monday", meal, protein, fats, carbohydrates, description);
                    addedDays.append("Monday, ");
                }
                if (tueCheck.isChecked()) {
                    dbHandler.addMeal(table, "Tuesday", meal, protein, fats, carbohydrates, description);
                    addedDays.append("Tuesday, ");
                }
                if (wedCheck.isChecked()) {
                    dbHandler.addMeal(table, "Wednesday", meal, protein, fats, carbohydrates, description);
                    addedDays.append("Wednesday, ");
                }
                if (thuCheck.isChecked()) {
                    dbHandler.addMeal(table, "Thursday", meal, protein, fats, carbohydrates, description);
                    addedDays.append("Thursday, ");
                }
                if (friCheck.isChecked()) {
                    dbHandler.addMeal(table, "Friday", meal, protein, fats, carbohydrates, description);
                    addedDays.append("Friday, ");
                }
                if (satCheck.isChecked()) {
                    dbHandler.addMeal(table, "Saturday", meal, protein, fats, carbohydrates, description);
                    addedDays.append("Saturday, ");
                }
                if (addedDays.length() > 0) {
                    addedDays.setLength(addedDays.length() - 2);
                }

                Toast.makeText(context, addedDays.toString(), Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}
