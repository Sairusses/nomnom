package com.example.nomnom;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.LeadingMarginSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.progressindicator.CircularProgressIndicator;

public class DashboardFragment extends Fragment {
    private TextView name, body_type, description, bmi, fats_fraction, protein_fraction, carbs_fraction;
    private EditText age, weight, height;
    private Spinner sex;
    private DBHandler dbHandler;
    private CircularProgressIndicator fats_progress, protein_progress, carbs_progress;
    public static String daySelected = "";
    double maxFats = 0;
    double maxProteins = 0;
    double maxCarbs = 0;
    double currFats = 0;
    double currProteins = 0;
    double currCarbs = 0;
    int counter = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dashboard_fragment, container, false);
        name = view.findViewById(R.id.profile_name);
        body_type = view.findViewById(R.id.body_type);
        description = view.findViewById(R.id.description);
        bmi = view.findViewById(R.id.bmi);
        age = view.findViewById(R.id.age);
        weight = view.findViewById(R.id.weight);
        height = view.findViewById(R.id.height);
        sex = view.findViewById(R.id.sex_spinner);
        fats_progress = view.findViewById(R.id.fats_progress);
        protein_progress = view.findViewById(R.id.protein_progress);
        carbs_progress = view.findViewById(R.id.carbs_progress);
        fats_fraction = view.findViewById(R.id.fats_fraction);
        protein_fraction = view.findViewById(R.id.protein_fraction);
        carbs_fraction = view.findViewById(R.id.carbs_fraction);

        dbHandler = new DBHandler(getActivity());
        setDetails();
        maxProgress();
        currProgress();
        setFraction();

        return view;
    }
    @Override
    public void onResume() {
        super.onResume();
        if(counter >= 1){
            maxProgress();
            currProgress();
            setFraction();
        }
        counter++;
    }
    private void setFraction(){
        fats_fraction.setText((int)currFats + " / " + (int)maxFats);
        protein_fraction.setText((int)currProteins + " / " + (int)maxProteins);
        carbs_fraction.setText((int)currCarbs + " / " + (int)maxCarbs);
    }
    private void maxProgress() {
        String[] tables = {DBHandler.TABLE_BREAKFAST, DBHandler.TABLE_LUNCH, DBHandler.TABLE_DINNER};

        for (String table : tables) {
            Cursor cursor = dbHandler.getReadableDatabase().rawQuery(
                    "SELECT SUM(" + DBHandler.COLUMN_FAT + ") as TotalFats, " +
                            "SUM(" + DBHandler.COLUMN_PROTEIN + ") as TotalProteins, " +
                            "SUM(" + DBHandler.COLUMN_CARBOHYDRATE + ") as TotalCarbs " +
                            "FROM " + table, null);

            if (cursor != null && cursor.moveToFirst()) {
                int totalFatsIndex = cursor.getColumnIndex("TotalFats");
                int totalProteinsIndex = cursor.getColumnIndex("TotalProteins");
                int totalCarbsIndex = cursor.getColumnIndex("TotalCarbs");

                if (totalFatsIndex != -1 && totalProteinsIndex != -1 && totalCarbsIndex != -1) {
                    do {
                        maxFats += cursor.getDouble(totalFatsIndex);
                        maxProteins += cursor.getDouble(totalProteinsIndex);
                        maxCarbs += cursor.getDouble(totalCarbsIndex);
                    } while (cursor.moveToNext());
                }
                cursor.close();
            }
        }
        fats_progress.setMax((int) maxFats);
        protein_progress.setMax((int) maxProteins);
        carbs_progress.setMax((int) maxCarbs);
    }
    private void currProgress() {
        String[] tables = {DBHandler.TABLE_BREAKFAST, DBHandler.TABLE_LUNCH, DBHandler.TABLE_DINNER};

        for (String table : tables) {
            SQLiteDatabase db = dbHandler.getReadableDatabase();

            String sqlQuery = "SELECT SUM(" + DBHandler.COLUMN_FAT + ") as CurrFats, " +
                    "SUM(" + DBHandler.COLUMN_PROTEIN + ") as CurrProteins, " +
                    "SUM(" + DBHandler.COLUMN_CARBOHYDRATE + ") as CurrCarbs " +
                    "FROM " + table + " WHERE " + DBHandler.COLUMN_DAY_OF_WEEK +
                    " BETWEEN 'Sunday' AND ?";

            Cursor cursor = db.rawQuery(sqlQuery, new String[]{daySelected});

            if (cursor != null && cursor.moveToFirst()) {
                int currFatsIndex = cursor.getColumnIndex("CurrFats");
                int currProteinsIndex = cursor.getColumnIndex("CurrProteins");
                int currCarbsIndex = cursor.getColumnIndex("CurrCarbs");

                if (currFatsIndex != -1 && currProteinsIndex != -1 && currCarbsIndex != -1) {
                    do {
                        currFats += cursor.getDouble(currFatsIndex);
                        currProteins += cursor.getDouble(currProteinsIndex);
                        currCarbs += cursor.getDouble(currCarbsIndex);
                    } while (cursor.moveToNext());
                }
                cursor.close();
            }
        }

        fats_progress.setProgress((int) currFats);
        protein_progress.setProgress((int) currProteins);
        carbs_progress.setProgress((int) currCarbs);
    }



    private void setDetails() {
        SQLiteDatabase db = dbHandler.getReadableDatabase();
        Cursor cursor = db.query(DBHandler.TABLE_USER_PROFILE, null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            int nameIndex = cursor.getColumnIndex(DBHandler.COLUMN_NAME);
            int ageIndex = cursor.getColumnIndex(DBHandler.COLUMN_AGE);
            int heightIndex = cursor.getColumnIndex(DBHandler.COLUMN_HEIGHT);
            int weightIndex = cursor.getColumnIndex(DBHandler.COLUMN_WEIGHT);
            int sexIndex = cursor.getColumnIndex(DBHandler.COLUMN_SEX);

            if (nameIndex != -1 && ageIndex != -1 && heightIndex != -1 && weightIndex != -1 && sexIndex != -1) {
                String profileName = cursor.getString(nameIndex);
                name.setText(profileName);

                int profileAge = cursor.getInt(ageIndex);
                age.setText(String.valueOf(profileAge));

                double profileHeight = cursor.getDouble(heightIndex);
                height.setText(String.valueOf(profileHeight));

                double profileWeight = cursor.getDouble(weightIndex);
                weight.setText(String.valueOf(profileWeight));

                String profileSex = cursor.getString(sexIndex);
                setSexSpinner(profileSex);

                double bmiValue = calculateBMI(profileWeight, profileHeight);
                bmi.setText("BMI: " + String.format("%.2f", bmiValue));
                String descriptionText = getDescription(bmiValue);
                setIndentedText(description, descriptionText, 50);
                body_type.setText("You are " + getBodyType(bmiValue));
            }

            cursor.close();
        }

        db.close();
    }


    private void setSexSpinner(String sexValue) {
        if (sexValue.equals("Male")) {
            sex.setSelection(0);
        } else if (sexValue.equals("Female")) {
            sex.setSelection(1);
        }
    }

    private double calculateBMI(double weight, double height) {
        double heightM = height / 100;
        return weight / (heightM * heightM);
    }
    private void setIndentedText(TextView textView, String text, int indentSize) {
        SpannableString spannableString = new SpannableString(text);
        spannableString.setSpan(new LeadingMarginSpan.Standard(indentSize, 0), 0, text.length(), 0);
        textView.setText(spannableString);
    }

    private String getDescription(double bmi) {
        if (bmi < 18.5) {
            return "You are underweight. It’s important to eat a balanced diet with enough calories to support your health. Consider consulting a nutritionist for personalized advice.";
        } else if (bmi < 24.9) {
            return "Your weight is in the normal range. Great job maintaining a healthy balance! Keep up with your balanced diet and regular exercise.";
        } else if (bmi < 29.9) {
            return "You are slightly overweight. Incorporating regular physical activity and a balanced diet into your routine can help you achieve a healthier weight. Consider consulting with a healthcare provider for personalized advice.";
        } else if (bmi < 34.9) {
            return "You are in the obese category. It's important to adopt a healthier lifestyle with balanced nutrition and regular exercise. Consulting a healthcare provider or nutritionist can help you develop a plan tailored to your needs.";
        } else {
            return "You are severely obese. It’s crucial to address this to avoid potential health risks. Seek guidance from a healthcare provider to develop a personalized and effective weight management plan.";
        }
    }

    private String getBodyType(double bmi) {
        if (bmi < 18.5) {
            return "Underweight";
        } else if (bmi < 24.9) {
            return "Normal";
        } else if (bmi < 29.9) {
            return "Overweight";
        } else if (bmi < 34.9) {
            return "Obese";
        } else {
            return "Extremely obese";
        }
    }
}
