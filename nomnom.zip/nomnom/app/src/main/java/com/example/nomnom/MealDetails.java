package com.example.nomnom;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MealDetails extends AppCompatActivity {
    private DBHandler dbHandler;
    private String tableName;
    private String dayOfWeek;
    private int mealPosition;
    private EditText mealName, mealProtein, mealFat, mealCarbs, mealDescription;
    private Button updateButton, deleteButton;
    private String mealId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_meal_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHandler = new DBHandler(this);

        mealName = findViewById(R.id.meal_name);
        mealProtein = findViewById(R.id.meal_protein);
        mealFat = findViewById(R.id.meal_fat);
        mealCarbs = findViewById(R.id.meal_carbs);
        mealDescription = findViewById(R.id.meal_description);
        updateButton = findViewById(R.id.update_button);
        deleteButton = findViewById(R.id.delete_button);

        tableName = getIntent().getStringExtra("tableName");
        dayOfWeek = getIntent().getStringExtra("dayOfWeek");
        mealPosition = getIntent().getIntExtra("mealPosition", 0);

        loadMealDetails();

        updateButton.setOnClickListener(v -> updateMeal());
        deleteButton.setOnClickListener(v -> deleteMeal());
    }
    private void loadMealDetails() {
        Cursor cursor = dbHandler.getMeals(tableName, dayOfWeek);

        if (cursor.moveToPosition(mealPosition)) {
            mealId = cursor.getString(cursor.getColumnIndexOrThrow(DBHandler.COLUMN_MEAL_ID));
            mealName.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHandler.COLUMN_MEAL)));
            mealProtein.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHandler.COLUMN_PROTEIN)));
            mealFat.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHandler.COLUMN_FAT)));
            mealCarbs.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHandler.COLUMN_CARBOHYDRATE)));
            mealDescription.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHandler.COLUMN_DESCRIPTION)));
        }
        cursor.close();
    }

    private void updateMeal() {
        String name = mealName.getText().toString();
        double protein = Double.parseDouble(mealProtein.getText().toString());
        double fat = Double.parseDouble(mealFat.getText().toString());
        double carbs = Double.parseDouble(mealCarbs.getText().toString());
        String description = mealDescription.getText().toString();

        dbHandler.updateMeal(tableName, Integer.parseInt(mealId), dayOfWeek, name, protein, fat, carbs, description);
        Toast.makeText(this, "Meal updated", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void deleteMeal() {
        dbHandler.deleteMeal(tableName, Integer.parseInt(mealId));
        Toast.makeText(this, "Meal deleted", Toast.LENGTH_SHORT).show();
        finish();
    }
}