package com.example.nomnom;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.viewpager.widget.ViewPager;

import com.example.nomnom.R.id;
import com.google.android.material.tabs.TabLayout;

public class Intro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        if (isProfileCreated()) {
            startActivity(new Intent(Intro.this, MainActivity.class));
            finish();
        }

        setContentView(R.layout.activity_intro);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ViewPager viewPager = findViewById(R.id.intro_pager);
        int[] layouts = new int[]{
                R.layout.intro_page1,
                R.layout.intro_page2,
                R.layout.intro_page3
        };

        IntroAdapter pagerAdapter = new IntroAdapter(this, layouts);
        viewPager.setAdapter(pagerAdapter);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.intro_dots_indicator);
        tabLayout.setupWithViewPager(viewPager, true);

    }
    public void goToCreateProfile(View view){
        startActivity(new Intent(this, CreateProfile.class));
        finish();
    }
    private boolean isProfileCreated() {
        SharedPreferences prefs = getSharedPreferences("UserProfile", MODE_PRIVATE);
        return prefs.getBoolean("isProfileCreated", false);
    }


}